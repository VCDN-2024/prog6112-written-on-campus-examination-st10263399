/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class MovieTicketApp extends javax.swing.JFrame {

    private JComboBox<String> movieComboBox;
    private JTextField ticketPriceField;
    private JTextField numOfTicketsField;
    private JTextArea textArea;

    private IMovieTickets movieTickets;

    public MovieTicketApp() {
        // Instantiate the implementation of IMovieTickets
        movieTickets = new MovieTicketProcessor();

        // Set up the frame
        setTitle("Movie Tickets");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Movie Selection ComboBox
        JLabel movieLabel = new JLabel("Movie:");
        movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});

        // Number of Tickets Field
        JLabel numOfTicketsLabel = new JLabel("Number of Tickets:");
        numOfTicketsField = new JTextField(5);

        // Ticket Price Field
        JLabel ticketPriceLabel = new JLabel("Ticket Price:");
        ticketPriceField = new JTextField(5);

        // Text Area for Report
        textArea = new JTextArea(8, 30);
        textArea.setEditable(false);

        // Adding components to the frame
        add(movieLabel);
        add(movieComboBox);
        add(numOfTicketsLabel);
        add(numOfTicketsField);
        add(ticketPriceLabel);
        add(ticketPriceField);
        add(new JScrollPane(textArea));

        // Menu
        JMenuBar menuBar = new JMenuBar();

        // File Menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);

        // Tools Menu
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(new ProcessAction());
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(new ClearAction());
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);
    }

    private class ProcessAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                // Get inputs
                String movieName = (String) movieComboBox.getSelectedItem();
                int numberOfTickets = Integer.parseInt(numOfTicketsField.getText());
                double ticketPrice = Double.parseDouble(ticketPriceField.getText());

                // Create MovieTicketData object
                MovieTicketData data = new MovieTicketData(movieName, numberOfTickets, ticketPrice);

                // Validate inputs
                if (!movieTickets.ValidateData(data)) {
                    JOptionPane.showMessageDialog(null, "Please enter valid data.");
                    return;
                }

                // Calculate total price with VAT
                double totalWithVAT = movieTickets.CalculateTotalTicketPrice(numberOfTickets, ticketPrice);

                // Generate report
                String report = String.format("MOVIE NAME: %s\nMOVIE TICKET PRICE: R %.2f\nNUMBER OF TICKETS: %d\nTOTAL TICKET PRICE: R %.2f\n",
                        movieName, ticketPrice, numberOfTickets, totalWithVAT);

                // Display report in text area
                textArea.setText(report);

                // Save report to a file
                saveReportToFile(report);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numeric values for ticket price and number of tickets.");
            }
        }

        private void saveReportToFile(String report) {
            try (FileWriter writer = new FileWriter("report.txt")) {
                writer.write(report);
                JOptionPane.showMessageDialog(null, "Report saved to report.txt");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error saving report to file.");
            }
        }
    }

    private class ClearAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Clear all inputs and the text area
            movieComboBox.setSelectedIndex(0);
            ticketPriceField.setText("");
            numOfTicketsField.setText("");
            textArea.setText("");
        }
    }

   
    }

   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        JComboBox = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("MOVIE:");

        jLabel2.setText("NUMBER OF TICKETS:");

        jLabel3.setText("TICKET PRICE:");

        jLabel4.setText("TICKET REPORT:");

        JComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Napoleon", "Oppenheimer", "Damsel", " " }));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(38, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(85, 85, 85))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MovieTicketApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MovieTicketApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MovieTicketApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MovieTicketApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        SwingUtilities.invokeLater(() -> {
            MovieTicketApp app = new MovieTicketApp();
            app.setVisible(true);
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MovieTicketApp().setVisible(true);
}
        });
        

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> JComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}




/*reference list


1. Oracle (n.d.) *JComboBox (Java Platform SE 8)*. Available at: https://docs.oracle.com/javase/8/docs/api/javax/swing/JComboBox.html (Accessed: 12 November 2024).

2. Oracle (n.d.) *How to Use Text Areas* (The Java Tutorials). Available at: https://docs.oracle.com/javase/tutorial/uiswing/components/textarea.html (Accessed: 12 November 2024).

3. Oracle (n.d.) *FileWriter (Java Platform SE 8)*. Available at: https://docs.oracle.com/javase/8/docs/api/java/io/FileWriter.html (Accessed: 12 November 2024).

4. Oracle (n.d.) *Event Handling* (The Java Tutorials). Available at: https://docs.oracle.com/javase/tutorial/uiswing/events/index.html (Accessed: 12 November 2024).

5. Baeldung (2023) *Guide to Swing in Java* (Baeldung). Available at: https://www.baeldung.com/java-swing (Accessed: 12 November 2024).


*/
































