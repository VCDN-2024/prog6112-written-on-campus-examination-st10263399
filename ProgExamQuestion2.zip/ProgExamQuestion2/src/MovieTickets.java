/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
public class MovieTickets implements IMovieTickets {
    
 

  
    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        return numberOfTickets * ticketPrice * 1.15; // assuming 15% VAT
    }

    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        return movieTicketData.getNumberOfTickets() > 0 && movieTicketData.getTicketPrice() > 0;
    }
}