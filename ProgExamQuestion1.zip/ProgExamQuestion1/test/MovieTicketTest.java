/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MovieTicketTest {
    



    @Test
    void testTotalMovieSales() {
        MovieTicketTest movieTicket = new MovieTicketTest();
      
        int[] salesData = {3000, 1500, 1700}; 

      
        int totalSales = movieTicket.TotalMovieSales(salesData);

      
        int expectedTotalSales = 6200; 
        assertEquals(expectedTotalSales, totalSales, "Total sales should be 6200");
    }
}
