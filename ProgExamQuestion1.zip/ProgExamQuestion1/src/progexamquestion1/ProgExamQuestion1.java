/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progexamquestion1;

/**
 *
 * @author lab_services_student
 */
public class ProgExamQuestion1 {

   
    public static void main(String[] args) {
        String[] movies = {"Napoleon", "Oppenheimer"};

        // Ticket sales data 
        int[][] salesData = {
            {3000, 1500, 1700}, // Sales for Napoleon
            {3500, 1200, 1600}  // Sales for Oppenheimer
        };

        // MovieTickets
        MovieTicket ticketReport = new MovieTicket();

        // Calculate total sales 
        int[] totalSales = new int[movies.length];
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = ticketReport.TotalMovieSales(salesData[i]);
        }

        // Display 
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println("JAN\tFEB\tMAR");

        for (int i = 0; i < movies.length; i++) {
            System.out.print(movies[i] + "\t");
            for (int j = 0; j < salesData[i].length; j++) {
                System.out.print(salesData[i][j] + "\t");
            }
            System.out.println();
        }

        System.out.println();

        // Display total sales 
        for (int i = 0; i < movies.length; i++) {
            System.out.println("Total movie ticket sales for " + movies[i] + ": " + totalSales[i]);
        }

        // top-performing movie
        String topMovie = ticketReport.TopMovie(movies, totalSales);
        System.out.println("Top performing movie: " + topMovie);
      
    }
    
}













